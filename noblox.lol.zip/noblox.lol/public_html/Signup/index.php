<?php include("header.php"); ?>
<center>  
Signup Is Closed Due To Silly Reason:p