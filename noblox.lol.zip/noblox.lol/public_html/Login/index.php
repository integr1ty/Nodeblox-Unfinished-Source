<?php include("header.php"); ?>
<center>  
<!-- login.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login To NODEBLOX</title>
</head>
<body>
    <h2>Login</h2>
    <form action="login_process.php" method="post">
        <label for="username">Username:</label><br>
        <input type="text" id="username" name="username" required><br>
        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password" required><br>
        <input type="submit" value="Login">
    </form>
</body>
</html>
<img alt="Image" src="https://media.discordapp.net/attachments/1208275098738364488/1235063899720646756/Drawing-92.sketchpad.png?ex=66330264&amp;is=6631b0e4&amp;hm=426b8716f4375722521d1f2b81929a33e18598b69a66becf0ab3369e30f1ccdf&amp;=&amp;format=webp&amp;quality=lossless&amp;width=620&amp;height=620" style="width: 200px; height: 200px;">
  <center>
  (BETA)
  
