<?php include("header.php"); ?>
<center>
<img alt="Image" src="https://media.discordapp.net/attachments/1208275098738364488/1235065006580830228/ZKZg.gif?ex=6633036b&amp;is=6631b1eb&amp;hm=a958581fe4b976a026d24e9f7999fe611dc4155c2026cee90cd666896d1b28a6&amp;=&amp;width=593&amp;height=600" style="width: 300px; height: 300px;">
<html>
<head>
<style>
p.ex1 {
  font-size: 30px;
}
p.ex2 {
  font-size: 50px;
}
</style>
</head>
<body>


<p class="ex1">Logging In .</p>
<p class="ex2">Did You Know Nodeblox had 4 different names</p>

</body>
</html>